Dataset for Injin Woo, Introduction to Digital Humanities, 2026-10-30
Source: locally reviewed TEI encoding of Yi Kwang-su, Mujeong, chapters 31–40.
Files: original TEI; chapter_text/31.txt–40.txt extracted from div elements; said_segments.csv (one row per TEI said element); chapter_summary.csv (counts for Youngchae, who=#YC).